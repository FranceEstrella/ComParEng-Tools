"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, RefreshCw, Plus, Trash, Download, AlertCircle, BookOpen, Calendar } from "lucide-react"
import Link from "next/link"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { initialCourses, curriculumCodes } from "@/lib/course-data"
import { ThemeProvider } from "@/components/theme-provider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

// Time slot constants
const DAYS = ["M", "T", "W", "Th", "F", "S"]
const TIME_SLOTS = [
  "07:00",
  "07:30",
  "08:00",
  "08:30",
  "09:00",
  "09:30",
  "10:00",
  "10:30",
  "11:00",
  "11:30",
  "12:00",
  "12:30",
  "13:00",
  "13:30",
  "14:00",
  "14:30",
  "15:00",
  "15:30",
  "16:00",
  "16:30",
  "17:00",
  "17:30",
  "18:00",
  "18:30",
  "19:00",
  "19:30",
  "20:00",
  "20:30",
  "21:00",
]

// Course details map for quick lookup
const courseDetailsMap = initialCourses.reduce((map, course) => {
  map[course.code] = course
  return map
}, {})

// Interface for course data
interface CourseSection {
  courseCode: string
  section: string
  classSize: string
  remainingSlots: string
  meetingDays: string
  meetingTime: string
  room: string
  hasSlots: boolean
}

// Interface for active course from tracker
interface ActiveCourse {
  id: string
  code: string
  name: string
  credits: number
  status: string
}

// Interface for selected course with schedule info
interface SelectedCourse extends CourseSection {
  name: string
  credits: number
  timeStart: string
  timeEnd: string
  parsedDays: string[]
}

// Sample data for available courses - used as fallback
const sampleAvailableCourses = [
  {
    courseCode: "COE0001",
    section: "A",
    classSize: "40",
    remainingSlots: "15",
    meetingDays: "MW",
    meetingTime: "10:00:00-11:30:00",
    room: "Room 301",
    hasSlots: true,
  },
  {
    courseCode: "COE0003",
    section: "B",
    classSize: "35",
    remainingSlots: "5",
    meetingDays: "TTh",
    meetingTime: "13:00:00-14:30:00",
    room: "Room 201",
    hasSlots: true,
  },
  {
    courseCode: "GED0001",
    section: "C",
    classSize: "45",
    remainingSlots: "0",
    meetingDays: "F",
    meetingTime: "08:00:00-11:00:00",
    room: "Room 101",
    hasSlots: false,
  },
  {
    courseCode: "COE0005",
    section: "A",
    classSize: "30",
    remainingSlots: "10",
    meetingDays: "MW",
    meetingTime: "13:00:00-14:30:00",
    room: "Room 302",
    hasSlots: true,
  },
  {
    courseCode: "GED0004",
    section: "B",
    classSize: "35",
    remainingSlots: "8",
    meetingDays: "TTh",
    meetingTime: "08:00:00-09:30:00",
    room: "Room 202",
    hasSlots: true,
  },
]

// Extract department codes from course codes
const extractDepartmentCode = (courseCode: string): string => {
  const match = courseCode.match(/^[A-Z]+/)
  return match ? match[0] : "OTHER"
}

export default function ScheduleMaker() {
  const [availableCourses, setAvailableCourses] = useState<CourseSection[]>([])
  const [activeCourses, setActiveCourses] = useState<ActiveCourse[]>([])
  const [selectedCourses, setSelectedCourses] = useState<SelectedCourse[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null)
  const [coursesNeedingPetition, setCoursesNeedingPetition] = useState<ActiveCourse[]>([])
  const [scheduleImageURL, setScheduleImageURL] = useState<string | null>(null)
  const scheduleRef = useRef<HTMLDivElement>(null)
  const [showOnlyActive, setShowOnlyActive] = useState(true)
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().split("T")[0])

  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState("department")
  const [sortOrder, setSortOrder] = useState("asc")
  const [selectedDepartment, setSelectedDepartment] = useState<string>("all")
  const [viewMode, setViewMode] = useState<"card" | "table">("card")

  // Get all available department codes
  const departmentCodes = Array.from(
    new Set(availableCourses.map((course) => extractDepartmentCode(course.courseCode))),
  ).sort()

  // Fetch available courses from the API
  const fetchAvailableCourses = async () => {
    try {
      const response = await fetch("/api/get-available-courses")

      if (!response.ok) {
        throw new Error(`API returned status: ${response.status}`)
      }

      const result = await response.json()

      if (result.success) {
        return result.data
      } else {
        throw new Error(result.error || "Failed to fetch available courses")
      }
    } catch (err: any) {
      console.error("Error fetching available courses:", err)
      throw new Error(`Error fetching available courses: ${err.message}`)
    }
  }

  // Load active courses from localStorage
  const loadActiveCourses = () => {
    try {
      if (typeof window !== "undefined") {
        const savedCourses = localStorage.getItem("courseStatuses")
        if (savedCourses) {
          const parsedCourses = JSON.parse(savedCourses)
          return parsedCourses.filter((course: any) => course.status === "active")
        }
      }
      return []
    } catch (err) {
      console.error("Error loading active courses from localStorage:", err)
      return []
    }
  }

  // Fetch both available courses and active courses
  const fetchData = async () => {
    try {
      setLoading(true)
      setError(null)

      // Get available courses from API
      let availableCoursesData: CourseSection[] = []
      try {
        availableCoursesData = await fetchAvailableCourses()
        if (availableCoursesData.length === 0) {
          console.warn("No course data available, using sample data")
          availableCoursesData = sampleAvailableCourses
          setError("No course data available. Please use the extension to extract course data.")
        }
      } catch (err: any) {
        console.error("Failed to fetch available courses:", err)
        setError(err.message || "Failed to fetch available courses")
        availableCoursesData = sampleAvailableCourses
      }

      // Load active courses from localStorage
      const activeCoursesData = loadActiveCourses()

      setAvailableCourses(availableCoursesData)
      setActiveCourses(activeCoursesData)

      // Find active courses that need petition (no available sections)
      const availableCourseCodes = availableCoursesData.map((course) => course.courseCode)
      const needPetition = activeCoursesData.filter((course) => !availableCourseCodes.includes(course.code))
      setCoursesNeedingPetition(needPetition)

      setLastUpdated(new Date())
    } catch (err: any) {
      setError("Error fetching data: " + (err.message || "Unknown error"))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    const fetchDataAndCheckFilter = async () => {
      await fetchData()

      // Check if there's a filtered course code from Academic Planner
      const filterCourseCode = localStorage.getItem("filterCourseCode")
      if (filterCourseCode) {
        setSearchTerm(filterCourseCode)
        // Clear the filter after using it
        localStorage.removeItem("filterCourseCode")
      }
    }

    fetchDataAndCheckFilter()
  }, [])

  // Filter courses based on active status and curriculum
  const filteredCourses = availableCourses.filter((course) => {
    if (showOnlyActive) {
      return (
        curriculumCodes.includes(course.courseCode) && activeCourses.some((active) => active.code === course.courseCode)
      )
    } else {
      return true // Show all courses when showOnlyActive is false
    }
  })

  // Clean and normalize time string
  const cleanTimeString = (timeString: string): string => {
    // Check if there are multiple identical times (e.g., "15:00:00-16:50:00 / 15:00:00-16:50:00")
    const times = timeString.split(" / ")

    // If all times are the same, just return one
    if (times.every((time) => time === times[0])) {
      // Format a single time (e.g., "15:00:00-16:50:00" to "15:00-16:50")
      const [start, end] = times[0].split("-")
      return `${start.substring(0, 5)}-${end.substring(0, 5)}`
    }

    // If times are different, format each one and join them
    return times
      .map((time) => {
        const [start, end] = time.split("-")
        return `${start.substring(0, 5)}-${end.substring(0, 5)}`
      })
      .join(" / ")
  }

  // Clean and normalize room string
  const cleanRoomString = (roomString: string): string => {
    // Check if there are multiple rooms (e.g., "E611 / E611")
    const rooms = roomString.split(" / ")

    // If all rooms are the same, just return one
    if (rooms.every((room) => room === rooms[0])) {
      return rooms[0]
    }

    // If rooms are different, return as is
    return roomString
  }

  // Parse time string (e.g., "10:00:00-11:30:00") into start and end times
  const parseTimeRange = (timeString: string): { start: string; end: string } => {
    const [start, end] = timeString.split("-")
    return {
      start: start.substring(0, 5), // Get HH:MM format
      end: end.substring(0, 5), // Get HH:MM format
    }
  }

  // Parse days string (e.g., "MW" or "TTh") into array of days
  const parseDays = (daysString: string): string[] => {
    if (!daysString) return []

    const days: string[] = []
    let i = 0

    while (i < daysString.length) {
      if (i < daysString.length - 1 && daysString.substring(i, i + 2) === "Th") {
        days.push("Th")
        i += 2
      } else {
        days.push(daysString[i])
        i += 1
      }
    }

    return days
  }

  // Check if a course conflicts with already selected courses
  const hasScheduleConflict = (course: CourseSection): boolean => {
    if (!course.meetingTime || !course.meetingDays) return false

    const { start: newStart, end: newEnd } = parseTimeRange(course.meetingTime)
    const newDays = parseDays(course.meetingDays)

    return selectedCourses.some((selected) => {
      // Skip if it's the same course code (we'll handle replacement separately)
      if (selected.courseCode === course.courseCode) return false

      // Check if days overlap - only check for conflicts on the same days
      const daysOverlap = selected.parsedDays.some((day) => newDays.includes(day))
      if (!daysOverlap) return false // No conflict if on different days

      // Check if times overlap
      const timeOverlap =
        (newStart >= selected.timeStart && newStart < selected.timeEnd) ||
        (newEnd > selected.timeStart && newEnd <= selected.timeEnd) ||
        (newStart <= selected.timeStart && newEnd >= selected.timeEnd)

      return timeOverlap
    })
  }

  // Check if a course with the same code is already selected
  const hasSameCourseCode = (course: CourseSection): boolean => {
    return selectedCourses.some((selected) => selected.courseCode === course.courseCode)
  }

  // Get the selected course with the same code
  const getSelectedCourseWithSameCode = (course: CourseSection): SelectedCourse | undefined => {
    return selectedCourses.find((selected) => selected.courseCode === course.courseCode)
  }

  const sortCourses = (courses: CourseSection[]) => {
    return [...courses].sort((a, b) => {
      let valueA, valueB

      if (sortBy === "courseCode") {
        valueA = a.courseCode
        valueB = b.courseCode
      } else if (sortBy === "department") {
        // Extract department code (first 3-4 characters)
        valueA = extractDepartmentCode(a.courseCode)
        valueB = extractDepartmentCode(b.courseCode)

        // If departments are the same, sort by course code
        if (valueA === valueB) {
          valueA = a.courseCode
          valueB = b.courseCode
        }
      } else if (sortBy === "remainingSlots") {
        valueA = Number.parseInt(a.remainingSlots)
        valueB = Number.parseInt(b.remainingSlots)
      } else if (sortBy === "meetingDays") {
        valueA = a.meetingDays
        valueB = b.meetingDays
      } else {
        valueA = a[sortBy]
        valueB = b[sortBy]
      }

      if (sortOrder === "asc") {
        return valueA > valueB ? 1 : -1
      } else {
        return valueA < valueB ? 1 : -1
      }
    })
  }

  // Add a course to the selected courses
  const addCourse = (course: CourseSection) => {
    // Check if a course with the same code is already selected
    const existingCourse = selectedCourses.find((selected) => selected.courseCode === course.courseCode)

    if (existingCourse) {
      // Replace the existing course with the new one
      setSelectedCourses((prev) =>
        prev.map((selected) =>
          selected.courseCode === course.courseCode
            ? {
                ...course,
                name: courseDetailsMap[course.courseCode]?.name || "Unknown Course",
                credits: courseDetailsMap[course.courseCode]?.credits || 3,
                timeStart: parseTimeRange(course.meetingTime).start,
                timeEnd: parseTimeRange(course.meetingTime).end,
                parsedDays: parseDays(course.meetingDays),
              }
            : selected,
        ),
      )
      return
    }

    // Find the course details from active courses or courseDetailsMap
    const courseDetails = activeCourses.find((active) => active.code === course.courseCode) || {
      name: courseDetailsMap[course.courseCode]?.name || "Unknown Course",
      credits: courseDetailsMap[course.courseCode]?.credits || 3,
    }

    // Parse time and days
    const { start, end } = parseTimeRange(course.meetingTime)
    const parsedDays = parseDays(course.meetingDays)

    // Add to selected courses
    setSelectedCourses((prev) => [
      ...prev,
      {
        ...course,
        name: courseDetails.name,
        credits: courseDetails.credits,
        timeStart: start,
        timeEnd: end,
        parsedDays,
      },
    ])
  }

  // Remove a course from selected courses
  const removeCourse = (courseCode: string, section: string) => {
    setSelectedCourses((prev) =>
      prev.filter((course) => !(course.courseCode === courseCode && course.section === section)),
    )
  }

  // Download the schedule as an image
  const downloadSchedule = () => {
    if (!scheduleRef.current) return

    try {
      // Create a canvas element
      const canvas = document.createElement("canvas")
      const ctx = canvas.getContext("2d")
      if (!ctx) {
        throw new Error("Could not get canvas context")
      }

      // Set canvas dimensions
      const scheduleElement = scheduleRef.current
      const width = scheduleElement.offsetWidth
      const height = scheduleElement.offsetHeight
      canvas.width = width * 2 // Higher resolution
      canvas.height = height * 2
      ctx.scale(2, 2)

      // Fill background
      ctx.fillStyle = "#ffffff"
      ctx.fillRect(0, 0, width, height)

      // Draw grid lines
      ctx.strokeStyle = "#e5e7eb"
      ctx.lineWidth = 1

      // Draw days header
      ctx.fillStyle = "#1f2937"
      ctx.font = "bold 14px Arial"
      ctx.textAlign = "center"

      const dayWidth = width / DAYS.length
      DAYS.forEach((day, i) => {
        const x = i * dayWidth + dayWidth / 2
        ctx.fillText(day, x, 30)
      })

      // Draw time slots
      ctx.font = "12px Arial"
      ctx.textAlign = "right"
      const timeHeight = (height - 40) / TIME_SLOTS.length
      TIME_SLOTS.forEach((time, i) => {
        const y = 40 + i * timeHeight + timeHeight / 2
        ctx.fillText(time, 50, y)
      })

      // Draw grid
      ctx.beginPath()
      // Horizontal lines
      for (let i = 0; i <= TIME_SLOTS.length; i++) {
        const y = 40 + i * timeHeight
        ctx.moveTo(0, y)
        ctx.lineTo(width, y)
      }
      // Vertical lines
      for (let i = 0; i <= DAYS.length; i++) {
        const x = i * dayWidth
        ctx.moveTo(x, 40)
        ctx.lineTo(x, height)
      }
      ctx.stroke()

      // Draw courses
      selectedCourses.forEach((course) => {
        course.parsedDays.forEach((day) => {
          const dayIndex = DAYS.indexOf(day)
          if (dayIndex === -1) return

          // Calculate position
          const startParts = course.timeStart.split(":")
          const endParts = course.timeEnd.split(":")
          const startHour = Number.parseInt(startParts[0])
          const startMinute = Number.parseInt(startParts[1])
          const endHour = Number.parseInt(endParts[0])
          const endMinute = Number.parseInt(endParts[1])

          // Find closest time slots
          const startTimeIndex = TIME_SLOTS.findIndex((t) => {
            const [h, m] = t.split(":").map(Number)
            return h > startHour || (h === startHour && m >= startMinute)
          })

          const endTimeIndex =
            TIME_SLOTS.findIndex((t) => {
              const [h, m] = t.split(":").map(Number)
              return h > endHour || (h === endHour && m >= endMinute)
            }) - 1

          if (startTimeIndex === -1 || endTimeIndex === -1) return

          const x = dayIndex * dayWidth
          const y = 40 + startTimeIndex * timeHeight
          const courseHeight = (endTimeIndex - startTimeIndex + 1) * timeHeight

          // Draw course box
          ctx.fillStyle = "#3b82f6"
          ctx.fillRect(x + 2, y + 2, dayWidth - 4, courseHeight - 4)

          // Draw course text
          ctx.fillStyle = "#ffffff"
          ctx.font = "bold 12px Arial"
          ctx.textAlign = "center"
          ctx.fillText(course.courseCode, x + dayWidth / 2, y + 20)
          ctx.font = "10px Arial"
          ctx.fillText(course.section, x + dayWidth / 2, y + 35)
          ctx.fillText(`${course.timeStart}-${course.timeEnd}`, x + dayWidth / 2, y + 50)
          ctx.fillText(course.room, x + dayWidth / 2, y + 65)
        })
      })

      // Convert canvas to image
      const dataUrl = canvas.toDataURL("image/png")

      // Create download link
      const link = document.createElement("a")
      link.href = dataUrl
      link.download = "my-schedule.png"
      link.click()
    } catch (err) {
      console.error("Error generating schedule image:", err)
      setError("Failed to download schedule. Please try again.")
    }
  }

  // Add schedule to Google Calendar
  const addToGoogleCalendar = () => {
    if (selectedCourses.length === 0) return

    // Format the start date
    const formatDate = (date: string): string => {
      return date.replace(/-/g, "")
    }

    // Calculate the end date (12 weeks from start date)
    const startDateObj = new Date(startDate)
    const endDateObj = new Date(startDateObj)
    endDateObj.setDate(endDateObj.getDate() + 12 * 7) // 12 weeks
    const endDateStr = endDateObj.toISOString().split("T")[0]

    // Create Google Calendar events for each course
    selectedCourses.forEach((course) => {
      course.parsedDays.forEach((day) => {
        // Map day to number (0 = Sunday, 1 = Monday, etc.)
        const dayMap: Record<string, number> = { M: 1, T: 2, W: 3, Th: 4, F: 5, S: 6 }
        const dayNum = dayMap[day]

        if (dayNum === undefined) return

        // Calculate first class date
        const firstClass = new Date(startDate)
        const currentDay = firstClass.getDay()
        const daysToAdd = (dayNum - currentDay + 7) % 7
        firstClass.setDate(firstClass.getDate() + daysToAdd)
        const firstClassStr = firstClass.toISOString().split("T")[0]

        // Parse start and end times
        const [startHour, startMinute] = course.timeStart.split(":").map(Number)
        const [endHour, endMinute] = course.timeEnd.split(":").map(Number)

        // Format times for Google Calendar
        const startDateTime = `${formatDate(firstClassStr)}T${startHour.toString().padStart(2, "0")}${startMinute.toString().padStart(2, "0")}00`
        const endDateTime = `${formatDate(firstClassStr)}T${endHour.toString().padStart(2, "0")}${endMinute.toString().padStart(2, "0")}00`

        // Create recurrence rule (weekly for 12 weeks)
        const recurrence = `RRULE:FREQ=WEEKLY;COUNT=12`

        // Create Google Calendar URL
        const calendarUrl = `https://www.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(`${course.courseCode} - ${course.name}`)}&details=${encodeURIComponent(`Section: ${course.section}\nRoom: ${course.room}`)}&location=${encodeURIComponent(course.room)}&dates=${startDateTime}/${endDateTime}&recur=${encodeURIComponent(recurrence)}`

        // Open Google Calendar in a new tab
        window.open(calendarUrl, "_blank")
      })
    })
  }

  // Group courses by department
  const groupCoursesByDepartment = (courses: CourseSection[]) => {
    const grouped = courses.reduce(
      (acc, course) => {
        const dept = extractDepartmentCode(course.courseCode)
        if (!acc[dept]) acc[dept] = []
        acc[dept].push(course)
        return acc
      },
      {} as Record<string, CourseSection[]>,
    )

    // Sort departments
    return Object.entries(grouped)
      .sort(([deptA], [deptB]) => deptA.localeCompare(deptB))
      .map(([dept, courses]) => ({
        department: dept,
        courses: sortCourses(courses),
      }))
  }

  const getFilteredAndSortedCourses = () => {
    // First filter by search term and department
    const filtered = filteredCourses.filter((course) => {
      const matchesSearch =
        searchTerm === "" ||
        course.courseCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (courseDetailsMap[course.courseCode]?.name || "").toLowerCase().includes(searchTerm.toLowerCase())

      const matchesDepartment =
        selectedDepartment === "all" || extractDepartmentCode(course.courseCode) === selectedDepartment

      return matchesSearch && matchesDepartment
    })

    // Then sort
    return sortCourses(filtered)
  }

  // Open the student portal course offerings page
  const openStudentPortal = () => {
    window.open("https://solar.feutech.edu.ph/course/offerings", "_blank")
  }

  // Get the position and height for a course in the schedule grid
  const getCoursePosition = (course: SelectedCourse) => {
    const startParts = course.timeStart.split(":")
    const endParts = course.timeEnd.split(":")

    const startHour = Number.parseInt(startParts[0])
    const startMinute = Number.parseInt(startParts[1])
    const endHour = Number.parseInt(endParts[0])
    const endMinute = Number.parseInt(endParts[1])

    // Calculate start position (each hour is 60px, each minute is 1px)
    const startPosition = (startHour - 7) * 60 + startMinute

    // Calculate height (difference between end and start in minutes)
    const height = (endHour - startHour) * 60 + (endMinute - startMinute)

    return { top: startPosition, height }
  }

  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false} disableTransitionOnChange>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-200">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <div className="flex flex-col sm:flex-row gap-3 mb-4">
              <Link href="/course-tracker">
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4" />
                  Back to Course Tracker
                </Button>
              </Link>
              <Link href="/">
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <ArrowLeft className="h-4 w-4" />
                  Back to Home
                </Button>
              </Link>
            </div>
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-3xl font-bold">Schedule Maker</h1>
                <p className="text-gray-600 dark:text-gray-400 mt-2">
                  Create your perfect class schedule with available course sections
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setViewMode(viewMode === "card" ? "table" : "card")}
                  className="flex items-center gap-2"
                >
                  {viewMode === "card" ? "Table View" : "Card View"}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={fetchData}
                  disabled={loading}
                  className="flex items-center gap-2"
                >
                  <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
                  Refresh Data
                </Button>
              </div>
            </div>
            {lastUpdated && (
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Last updated: {lastUpdated.toLocaleString()}
              </p>
            )}
          </div>

          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                {error}
                <div className="mt-4">
                  <Button onClick={openStudentPortal} className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    Open Student Portal Course Offerings
                  </Button>
                </div>
              </AlertDescription>
            </Alert>
          )}

          {/* Note about Course Tracker integration */}
          <Alert className="mb-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Course Tracker Integration</AlertTitle>
            <AlertDescription>
              The Schedule Maker shows available sections for courses marked as "Active" in the Course Tracker. If you
              don't see your desired courses, go back to the Course Tracker and mark them as active.
            </AlertDescription>
          </Alert>

          {/* Courses Needing Petition */}
          {coursesNeedingPetition.length > 0 && showOnlyActive && (
            <Alert className="mb-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 text-yellow-700 dark:text-yellow-300">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Courses Needing Petition</AlertTitle>
              <AlertDescription>
                <p className="mb-2">
                  The following active courses have no available sections and may require a petition:
                </p>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-yellow-200 dark:divide-yellow-800">
                    <thead>
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-medium">Course Code</th>
                        <th className="px-4 py-2 text-left text-xs font-medium">Course Name</th>
                        <th className="px-4 py-2 text-left text-xs font-medium">Credits</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-yellow-200 dark:divide-yellow-800">
                      {coursesNeedingPetition.map((course) => (
                        <tr key={course.id}>
                          <td className="px-4 py-2 text-sm">{course.code}</td>
                          <td className="px-4 py-2 text-sm">{course.name}</td>
                          <td className="px-4 py-2 text-sm">{course.credits}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </AlertDescription>
            </Alert>
          )}

          {loading ? (
            <div className="text-center py-10">
              <p className="text-gray-600 dark:text-gray-400">Loading available courses...</p>
            </div>
          ) : (
            <Tabs defaultValue="available" className="w-full">
              <TabsList className="mb-4">
                <TabsTrigger value="available">Available Courses</TabsTrigger>
                <TabsTrigger value="selected">Selected Courses ({selectedCourses.length})</TabsTrigger>
                <TabsTrigger value="schedule">Schedule View</TabsTrigger>
              </TabsList>

              {/* Available Courses Tab */}
              <TabsContent value="available">
                <div>
                  <div className="mb-4 flex flex-col md:flex-row gap-4 items-end">
                    <div className="w-full md:w-1/4">
                      <Label htmlFor="search-courses">Search Courses</Label>
                      <Input
                        id="search-courses"
                        placeholder="Search by code or name..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <div className="w-full md:w-1/4">
                      <Label htmlFor="department-filter">Department</Label>
                      <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                        <SelectTrigger id="department-filter">
                          <SelectValue placeholder="Select department..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Departments</SelectItem>
                          {departmentCodes.map((dept) => (
                            <SelectItem key={dept} value={dept}>
                              {dept}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="w-full md:w-1/4">
                      <Label htmlFor="sort-by">Sort By</Label>
                      <Select value={sortBy} onValueChange={setSortBy}>
                        <SelectTrigger id="sort-by">
                          <SelectValue placeholder="Sort by..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="department">Department</SelectItem>
                          <SelectItem value="courseCode">Course Code</SelectItem>
                          <SelectItem value="section">Section</SelectItem>
                          <SelectItem value="remainingSlots">Available Slots</SelectItem>
                          <SelectItem value="meetingDays">Meeting Days</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="w-full md:w-1/4">
                      <Label htmlFor="sort-order">Order</Label>
                      <Select value={sortOrder} onValueChange={setSortOrder}>
                        <SelectTrigger id="sort-order">
                          <SelectValue placeholder="Sort order..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="asc">Ascending</SelectItem>
                          <SelectItem value="desc">Descending</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 mb-4">
                    <Switch id="show-active-only" checked={showOnlyActive} onCheckedChange={setShowOnlyActive} />
                    <Label htmlFor="show-active-only">Show only active courses from Course Tracker</Label>
                  </div>

                  <p className="mb-4">
                    Found {getFilteredAndSortedCourses().length} course sections
                    {showOnlyActive ? " for your active courses" : ""} (out of {availableCourses.length} total extracted
                    courses).
                  </p>

                  {getFilteredAndSortedCourses().length === 0 ? (
                    <div className="bg-yellow-100 dark:bg-yellow-900/30 border border-yellow-400 dark:border-yellow-700 text-yellow-700 dark:text-yellow-400 px-4 py-3 rounded mb-4">
                      <p>
                        No courses match your current filters. Try adjusting your search criteria or department filter.
                      </p>
                      {showOnlyActive && (
                        <div className="mt-4">
                          <Link href="/course-tracker">
                            <Button className="flex items-center gap-2">
                              <BookOpen className="h-4 w-4" />
                              Go to Course Tracker
                            </Button>
                          </Link>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {getFilteredAndSortedCourses().map((course, index) => {
                        const courseDetails = activeCourses.find((active) => active.code === course.courseCode) || {
                          name: courseDetailsMap[course.courseCode]?.name || "Unknown Course",
                          credits: courseDetailsMap[course.courseCode]?.credits || 3,
                        }
                        const isConflict = hasScheduleConflict(course)
                        const isAlreadySelected = selectedCourses.some(
                          (selected) =>
                            selected.courseCode === course.courseCode && selected.section === course.section,
                        )
                        const hasSameCode = hasSameCourseCode(course) && !isAlreadySelected

                        return (
                          <Card
                            key={index}
                            className={`bg-white dark:bg-gray-800 shadow-md transition-shadow ${
                              isConflict ? "border-red-300 dark:border-red-700" : ""
                            }`}
                          >
                            <CardHeader className="pb-2">
                              <div className="flex justify-between items-start">
                                <div>
                                  <CardTitle className="text-lg font-bold">{course.courseCode}</CardTitle>
                                  <p className="text-sm font-medium">{courseDetails.name}</p>
                                </div>
                                <Badge
                                  variant={course.hasSlots ? "success" : "destructive"}
                                  className={`px-2 py-1 text-xs font-semibold ${
                                    course.hasSlots
                                      ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
                                      : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"
                                  }`}
                                >
                                  {course.hasSlots ? `${course.remainingSlots} slots` : "Full"}
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-600 dark:text-gray-400">Section: {course.section}</p>
                            </CardHeader>

                            <CardContent>
                              <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                  <span className="font-medium">Days:</span>
                                  <span>{course.meetingDays}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="font-medium">Time:</span>
                                  <span>{cleanTimeString(course.meetingTime)}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="font-medium">Room:</span>
                                  <span>{cleanRoomString(course.room)}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="font-medium">Class Size:</span>
                                  <span>
                                    {course.remainingSlots}/{course.classSize}
                                  </span>
                                </div>
                              </div>
                            </CardContent>

                            <div className="p-4 pt-0">
                              {hasSameCode ? (
                                <Popover>
                                  <PopoverTrigger asChild>
                                    <Button
                                      className="w-full"
                                      variant="outline"
                                      disabled={!course.hasSlots && !isAlreadySelected}
                                    >
                                      Replace Section
                                    </Button>
                                  </PopoverTrigger>
                                  <PopoverContent className="w-80">
                                    <div className="space-y-4">
                                      <h4 className="font-medium">Replace Existing Section</h4>
                                      <p className="text-sm">
                                        You already have this course in your schedule. Do you want to replace it with
                                        section {course.section}?
                                      </p>
                                      <div className="flex justify-end gap-2">
                                        <Button size="sm" onClick={() => addCourse(course)}>
                                          Yes, Replace
                                        </Button>
                                      </div>
                                    </div>
                                  </PopoverContent>
                                </Popover>
                              ) : (
                                <Button
                                  className="w-full"
                                  variant={isAlreadySelected ? "destructive" : isConflict ? "outline" : "default"}
                                  disabled={!course.hasSlots && !isAlreadySelected && isConflict}
                                  onClick={() => {
                                    if (isAlreadySelected) {
                                      removeCourse(course.courseCode, course.section)
                                    } else {
                                      addCourse(course)
                                    }
                                  }}
                                >
                                  {isAlreadySelected ? (
                                    <>
                                      <Trash className="h-4 w-4 mr-2" />
                                      Remove from Schedule
                                    </>
                                  ) : isConflict ? (
                                    <>
                                      <AlertCircle className="h-4 w-4 mr-2" />
                                      Conflicts
                                    </>
                                  ) : (
                                    <>
                                      <Plus className="h-4 w-4 mr-2" />
                                      Add to Schedule
                                    </>
                                  )}
                                </Button>
                              )}
                            </div>
                          </Card>
                        )
                      })}
                    </div>
                  )}
                </div>
              </TabsContent>

              {/* Selected Courses Tab */}
              <TabsContent value="selected">
                {selectedCourses.length === 0 ? (
                  <div className="bg-blue-100 dark:bg-blue-900/30 border border-blue-400 dark:border-blue-700 text-blue-700 dark:text-blue-400 px-4 py-3 rounded mb-4">
                    <p>No courses selected yet. Add courses from the Available Courses tab to build your schedule.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {selectedCourses.map((course, index) => (
                      <Card key={index} className="bg-white dark:bg-gray-800 shadow-md transition-shadow">
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <div>
                              <CardTitle className="text-lg font-bold">{course.courseCode}</CardTitle>
                              <p className="text-sm font-medium">{course.name}</p>
                            </div>
                            <Badge
                              variant={course.hasSlots ? "success" : "destructive"}
                              className={`px-2 py-1 text-xs font-semibold ${
                                course.hasSlots
                                  ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
                                  : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"
                              }`}
                            >
                              {course.hasSlots ? `${course.remainingSlots} slots` : "Full"}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Section: {course.section}</p>
                        </CardHeader>

                        <CardContent>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="font-medium">Days:</span>
                              <span>{course.meetingDays}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="font-medium">Time:</span>
                              <span>{cleanTimeString(course.meetingTime)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="font-medium">Room:</span>
                              <span>{cleanRoomString(course.room)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="font-medium">Class Size:</span>
                              <span>
                                {course.remainingSlots}/{course.classSize}
                              </span>
                            </div>
                          </div>
                        </CardContent>

                        <div className="p-4 pt-0">
                          <Button
                            className="w-full"
                            variant="destructive"
                            onClick={() => removeCourse(course.courseCode, course.section)}
                          >
                            <Trash className="h-4 w-4 mr-2" />
                            Remove from Schedule
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              {/* Schedule View Tab */}
              <TabsContent value="schedule">
                {selectedCourses.length === 0 ? (
                  <div className="bg-blue-100 dark:bg-blue-900/30 border border-blue-400 dark:border-blue-700 text-blue-700 dark:text-blue-400 px-4 py-3 rounded mb-4">
                    <p>No courses selected yet. Add courses from the Available Courses tab to build your schedule.</p>
                  </div>
                ) : (
                  <div>
                    <div className="mb-4 flex flex-col md:flex-row gap-4 justify-between items-center">
                      <div className="w-full md:w-1/3">
                        <Label htmlFor="start-date">Term Start Date (for Calendar Export)</Label>
                        <Input
                          id="start-date"
                          type="date"
                          value={startDate}
                          onChange={(e) => setStartDate(e.target.value)}
                          className="w-full"
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" onClick={downloadSchedule} className="flex items-center gap-2">
                          <Download className="h-4 w-4" />
                          Download Schedule
                        </Button>
                        <Button onClick={addToGoogleCalendar} className="flex items-center gap-2">
                          <Calendar className="h-4 w-4" />
                          Add to Google Calendar
                        </Button>
                      </div>
                    </div>

                    <div ref={scheduleRef} className="overflow-x-auto">
                      <div className="relative w-[900px] h-[1440px] bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-md">
                        {/* Time Slots */}
                        {TIME_SLOTS.map((time, index) => (
                          <div
                            key={time}
                            className="absolute left-0 w-full border-b border-gray-200 dark:border-gray-700"
                            style={{ top: index * 30 + 60 + "px", height: "30px" }}
                          >
                            <div className="absolute left-2 -translate-x-full -mt-2 text-xs text-gray-500 dark:text-gray-400">
                              {time}
                            </div>
                          </div>
                        ))}

                        {/* Days of the Week */}
                        {DAYS.map((day, index) => (
                          <div
                            key={day}
                            className="absolute top-0 w-[148px] h-full border-r border-gray-200 dark:border-gray-700"
                            style={{ left: index * 148 + 76 + "px" }}
                          >
                            <div className="absolute top-2 left-1/2 -translate-x-1/2 text-sm font-medium text-gray-700 dark:text-gray-300">
                              {day}
                            </div>
                          </div>
                        ))}

                        {/* Courses in Schedule */}
                        {selectedCourses.map((course, index) => {
                          return course.parsedDays.map((day, dayIndex) => {
                            const { top, height } = getCoursePosition(course)
                            const dayIdx = DAYS.indexOf(day)

                            if (dayIdx === -1) return null

                            return (
                              <div
                                key={`${index}-${day}`}
                                className="absolute bg-blue-500 dark:bg-blue-600 text-white text-xs font-medium rounded-md p-2 overflow-hidden"
                                style={{
                                  top: top + 60 + "px",
                                  left: dayIdx * 148 + 84 + "px",
                                  width: "132px",
                                  height: height + "px",
                                }}
                              >
                                <p className="truncate">{course.courseCode}</p>
                                <p className="truncate">{course.section}</p>
                                <p className="text-xxs">
                                  {course.timeStart} - {course.timeEnd}
                                </p>
                                <p className="text-xxs">{cleanRoomString(course.room)}</p>
                              </div>
                            )
                          })
                        })}
                      </div>
                    </div>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          )}
        </div>
      </div>
    </ThemeProvider>
  )
}
