export interface PatchNote {
  version: string
  date: string
  changes: string[]
}

export const patchNotes: PatchNote[] = [
  {
    version: "v1.38",
    date: "April 10, 2025",
    changes: [
      "Fixed 'Reset All Progress' button error in Course Tracker",
      "Added Patch Notes section to the home page",
      "Improved Schedule Maker with department filtering and grouping",
      "Added option to show all extracted courses in Schedule Maker",
      "Added manual extension installation guide",
      "Allow adding courses with no available slots to schedule",
      "Added course section replacement option",
      "Fixed visual bug in downloaded schedule images",
      "Changed calendar integration to use Google Calendar",
      "Minimized redundancy in time and room information display",
      "Fixed consistency of navigation buttons across all pages",
    ],
  },
  {
    version: "v1.37",
    date: "April 5, 2025",
    changes: [
      "Fixed newline character in calendar export",
      "Completed LOCATION field in ICS file",
      "Enhanced course conflict detection",
      "Improved course addition logic",
      "Added department sorting feature",
      "Enhanced calendar export functionality",
      "Added dynamic button text",
      "Added reset progress button",
      "Improved search experience",
      "Added year synchronization in Academic Planner",
      "Added cross-component communication",
    ],
  },
]
